import os
import numpy as np
from sklearn.cluster import KMeans
from PIL import Image
from scipy.ndimage import sobel
from pyswarm import pso
import time
import warnings

# 忽略特定警告
warnings.filterwarnings("ignore", category=RuntimeWarning)

# ========== 动态PSO和电子纸特性调整参数 ==========
LAMBDA = 0.6  # λ: 平衡灰度变化敏感性
DELTA = 0.4  # δ: 平衡边缘显著性
ALPHA = 0.8  # α: 控制HVS频率衰减
BETA = 0.3  # β: 边缘增强强度
GAMMA = 0.5  # γ: EPD补偿调节


# =============================================

def apply_threshold(value, centers):
    centers = np.array(centers)
    idx = np.argmin(np.abs(centers - value))
    return centers[idx]


def calculate_pixel_similarity(pixels, x, y, c, x_lim, y_lim):
    neighbors = [
        (x - 1, y - 1), (x, y - 1), (x + 1, y - 1),
        (x - 1, y), (x + 1, y),
        (x - 1, y + 1), (x, y + 1), (x + 1, y + 1)
    ]
    current_pixel = pixels[y, x, c]
    total_diff = 0
    valid_neighbors = 0

    for nx, ny in neighbors:
        if 0 <= nx < x_lim and 0 <= ny < y_lim:
            neighbor_pixel = pixels[ny, nx, c]
            total_diff += abs(current_pixel - neighbor_pixel)
            valid_neighbors += 1

    if valid_neighbors == 0:
        return 1.0

    avg_diff = total_diff / valid_neighbors
    similarity = 1.0 / (1.0 + avg_diff)
    return np.clip(similarity, 0.1, 1.0)  # 限制相似性范围


def objective_function(centers, data, clusters):
    centers = np.array(centers).reshape((clusters, 1))
    data = data.reshape(-1, 1)
    distances = np.abs(data - centers.T)  # 使用绝对距离代替范数计算
    min_distances = np.min(distances, axis=1)
    return np.sum(min_distances)


def pso_kmeans_initialization(data, clusters, particles=40, iterations=150):
    lb = np.min(data)
    ub = np.max(data)

    # 如果数据范围太小，调整边界
    if ub - lb < 10:
        lb = max(0, lb - 10)
        ub = min(255, ub + 10)

    xopt, fopt = pso(objective_function, lb=[lb] * clusters, ub=[ub] * clusters,
                     args=(data, clusters), swarmsize=particles, maxiter=iterations)

    # 确保中心点排序
    centers = np.sort(np.array(xopt).reshape((clusters, 1)), axis=0)
    return centers


def non_sequential_dither_with_kmeans_plus(img_path, output_path, clusters=16):
    img = Image.open(img_path)
    img = img.convert('RGB')
    pixels = np.array(img, dtype=np.float32)
    y_lim, x_lim, _ = pixels.shape

    # 创建处理后的像素副本
    processed_pixels = pixels.copy()

    # 分离通道
    r_channel = processed_pixels[..., 0].flatten()
    g_channel = processed_pixels[..., 1].flatten()
    b_channel = processed_pixels[..., 2].flatten()

    print("Initializing PSO for red channel...")
    centers_r = pso_kmeans_initialization(r_channel, clusters)
    print("Initializing PSO for green channel...")
    centers_g = pso_kmeans_initialization(g_channel, clusters)
    print("Initializing PSO for blue channel...")
    centers_b = pso_kmeans_initialization(b_channel, clusters)

    kmeans_r = KMeans(n_clusters=clusters, init=centers_r, n_init=1, random_state=0).fit(r_channel.reshape(-1, 1))
    kmeans_g = KMeans(n_clusters=clusters, init=centers_g, n_init=1, random_state=0).fit(g_channel.reshape(-1, 1))
    kmeans_b = KMeans(n_clusters=clusters, init=centers_b, n_init=1, random_state=0).fit(b_channel.reshape(-1, 1))

    centers_r = np.sort(kmeans_r.cluster_centers_.flatten())
    centers_g = np.sort(kmeans_g.cluster_centers_.flatten())
    centers_b = np.sort(kmeans_b.cluster_centers_.flatten())

    print("Red channel cluster centers:", centers_r)
    print("Green channel cluster centers:", centers_g)
    print("Blue channel cluster centers:", centers_b)

    # 转换为灰度图用于边缘检测
    grayscale = np.dot(processed_pixels[..., :3], [0.299, 0.587, 0.114])

    # 计算边缘梯度
    edges_x = sobel(grayscale, axis=0)
    edges_y = sobel(grayscale, axis=1)
    gradient_magnitude = np.sqrt(edges_x ** 2 + edges_y ** 2)

    # 避免除以零
    max_gradient = np.max(gradient_magnitude)
    if max_gradient > 0:
        gradient_magnitude = gradient_magnitude / max_gradient
    else:
        gradient_magnitude = np.zeros_like(gradient_magnitude)

    # 误差扩散矩阵
    diffusion_matrix = [
        (-1, -1, 1 / 32), (0, -1, 5 / 32), (1, -1, 3 / 32),
        (-1, 0, 7 / 32), (1, 0, 7 / 32),
        (-1, 1, 3 / 32), (0, 1, 5 / 32), (1, 1, 1 / 32)
    ]

    # 处理每个像素
    for y in range(y_lim):
        if y % 100 == 0:
            print(f"Processing row {y}/{y_lim}")

        for x in range(x_lim):
            for c, centers in enumerate([centers_r, centers_g, centers_b]):
                old_pixel = processed_pixels[y, x, c]
                new_pixel = apply_threshold(old_pixel, centers)
                processed_pixels[y, x, c] = new_pixel
                error = old_pixel - new_pixel

                # ========== 动态PSO权重调整 ==========
                # 计算局部灰度变化 (3x3邻域)
                y_start, y_end = max(0, y - 1), min(y + 2, y_lim)
                x_start, x_end = max(0, x - 1), min(x + 2, x_lim)
                local_region = processed_pixels[y_start:y_end, x_start:x_end, c]

                # 安全计算标准差
                if local_region.size > 1:
                    grayscale_variation = np.std(local_region)
                    if np.isnan(grayscale_variation):
                        grayscale_variation = 0
                else:
                    grayscale_variation = 0

                # 获取边缘显著性
                edge_significance = gradient_magnitude[y, x] if y < y_lim and x < x_lim else 0

                # 计算动态权重
                dynamic_weight = LAMBDA * grayscale_variation + DELTA * edge_significance
                # ===========================================

                # ========== 边缘增强 ==========
                edge_enhancement = BETA * gradient_magnitude[y, x] if y < y_lim and x < x_lim else 0
                # =====================================

                # 计算像素相似性
                similarity = calculate_pixel_similarity(processed_pixels, x, y, c, x_lim, y_lim)

                # 整合动态权重和边缘增强
                adjustment_factor = min(2.0, max(0.1, dynamic_weight * similarity + edge_enhancement))

                # 应用误差扩散
                for dx, dy, coeff in diffusion_matrix:
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < x_lim and 0 <= ny < y_lim:
                        distance = np.sqrt(dx ** 2 + dy ** 2)
                        weight = 1.0 / (1.0 + distance)
                        random_factor = np.random.uniform(0.9, 1.1)

                        # 应用调整因子并裁剪值
                        processed_pixels[ny, nx, c] += error * coeff * adjustment_factor * weight * random_factor
                        processed_pixels[ny, nx, c] = np.clip(processed_pixels[ny, nx, c], 0, 255)

    # ========== EPD特定补偿 ==========
    # 修正的EPD补偿公式
    for y in range(y_lim):
        for x in range(x_lim):
            for c in range(3):
                # 计算EPD补偿值 - 使用更安全的公式
                current_val = processed_pixels[y, x, c]
                normalized_val = current_val / 255.0
                epd_compensation = GAMMA * (1.0 - normalized_val)
                # 应用补偿并确保在范围内
                processed_pixels[y, x, c] = current_val * (1.0 + epd_compensation)
                processed_pixels[y, x, c] = np.clip(processed_pixels[y, x, c], 0, 255)
    # =======================================

    # 确保像素值在有效范围内
    processed_pixels = np.clip(processed_pixels, 0, 255)
    result_img = Image.fromarray(np.uint8(processed_pixels))
    result_img.save(output_path)


def process_folder(input_folder, output_folder, clusters=16):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for filename in os.listdir(input_folder):
        if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff')):
            input_path = os.path.join(input_folder, filename)
            output_path = os.path.join(output_folder, filename)
            print(f"\nProcessing {filename}...")
            start_time = time.time()

            try:
                non_sequential_dither_with_kmeans_plus(input_path, output_path, clusters)
            except Exception as e:
                print(f"Error processing {filename}: {str(e)}")
                continue

            end_time = time.time()
            time_taken = end_time - start_time
            print(f"Processed {filename} in {time_taken:.2f} seconds")


def main():
    input_folder = './input_images'
    output_folder = './output_images'
    process_folder(input_folder, output_folder)


if __name__ == '__main__':
    main()