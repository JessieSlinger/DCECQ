1. Overview
DCECQ is an advanced color quantization algorithm specifically designed for Electrophoretic Displays (EPDs). It combines dynamic Particle Swarm Optimization (PSO) clustering with human visual system modeling to achieve superior image quality on e-paper devices with limited color palettes.

Key Features:
- Dynamic PSO optimization for adaptive threshold selection
- HVS-based error diffusion for artifact reduction
- EPD-specific compensation for display optimization
- Support for 16-color quantization (configurable)

2. System Requirements
- Python 3.8+
- Supported OS: Windows, Linux, macOS

3. Dependencies
Install required packages:
pip install numpy pillow scikit-learn scipy pyswarm

4. Usage
(1) Prepare input images in a folder (e.g., ./input_images)
(2) Run main script:
python baseline.py

(3) Processed images will be saved in ./output_images

5. Configuration
Modify these parameters at the top of dcecq.py:
LAMBDA = 0.6 # Balance grayscale sensitivity (0-1)
DELTA = 0.4 # Balance edge significance (0-1)
ALPHA = 0.8 # HVS frequency attenuation (0-2)
BETA = 0.3 # Edge enhancement strength (0-1)
GAMMA = 0.5 # EPD compensation (0-1)
CLUSTERS = 16 # Number of output colors (8/16)


6. Input/Output
- Input: JPG, PNG, BMP, TIFF
- Output: Same name as the input file
- Note: Processing time ≈930s per 1280x960 image (CPU) ≈40s per 1280x960 image (NVIDIA RTX 3090)
-

7. License
For academic and research use only.